package com.okky.ezhousing.ui.auth.register

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.okky.ezhousing.R

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
    }
}