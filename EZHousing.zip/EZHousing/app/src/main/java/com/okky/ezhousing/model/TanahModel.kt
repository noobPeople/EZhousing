package com.okky.ezhousing.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TanahModel (
    var name: String,
    var price: String,
    var luas: String,
    var lokasi: String,
    var tipe_properti: String,
    var sertifikat: String,
    var photo: String
        ) : Parcelable