package com.okky.ezhousing.ui.designhome

import androidx.lifecycle.ViewModel

class DesignViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}