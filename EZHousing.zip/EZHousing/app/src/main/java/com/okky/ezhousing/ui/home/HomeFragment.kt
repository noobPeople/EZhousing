package com.okky.ezhousing.ui.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.okky.ezhousing.databinding.FragmentHomeBinding
import com.okky.ezhousing.model.TanahModel
import java.io.BufferedReader
import java.io.InputStreamReader
import com.github.doyaaaaaken.kotlincsv.dsl.csvReader


class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding

    private val list = ArrayList<TanahModel>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding?.root!!
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val homeViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[HomeViewModel::class.java]
        homeViewModel.setStoryData("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyLTNQTkpUcThldERFREtqaUkiLCJpYXQiOjE2NTQxNDk0MzV9.liCkv87vuE7XK6LZNk6pcRezsQwv61RVbzW6U2VeXcQ")

//        readCsv()

        list.addAll(listTanahs)
        showRecyclerList(list)

//        homeViewModel.story.observe(viewLifecycleOwner) {
//            Log.e("errorlagi: ", it.toString())
//            showRecyclerList(it)
//        }

//        homeViewModel.isLoading.observe(viewLifecycleOwner) {
//            isLoading(it)
//        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
//
//    private fun readCsv() {
//        val minput = InputStreamReader(activity?.assets?.open("tanah_jaksel(1).csv"))
//        val reader = BufferedReader(minput)
//
//        var line: String?
//        var displayData: String = ""
//
//        while (reader.readLine().also { line = it } != null) {
//            val row: List<String> = line!!.split(",")
//
//        }
//    }

    private val listTanahs: ArrayList<TanahModel>
        get() {
//            val minput = InputStreamReader(activity?.assets?.open("tanah_jaksel(1).csv"))
//            val reader = BufferedReader(minput)
//
//            var line: String?
//            var dataName: String = ""
//            var dataPrice: String = ""
//            var dataLuas: String = ""
//            var dataLokasi: String = ""
//            var dataTipe: String = ""
//            var dataSertifikat: String = ""
//            var dataPhoto: String = ""
//            val listTanah = ArrayList<TanahModel>()
//
//            while (reader.readLine().also { line = it } != null) {
//                val row: List<String> = line!!.split(",")
//                for (i in row) {
//                    println("ini hasilnya: $i")
//                }
//                val tanah = TanahModel(row[4], row[5], row[6], row[7], row[8], row[9], row[10])
//                listTanah.add(tanah)
//            }
//            return listTanah

            csvReader().open("app/src/main/java/com/okky/ezhousing/ui/home/tanah_jaksel(1).csv") {
                readAllAsSequence().forEach { row ->
                    //Do something
                    println(row) //[a, b, c]
                }
            }
            return listTanahs
        }

    private fun showRecyclerList(storyData: ArrayList<TanahModel>) {
        val layoutManager = LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        binding?.rvFavorit?.layoutManager = layoutManager
        val listTanahAdapter = NewAdapter(storyData as ArrayList<TanahModel>)
        binding?.rvFavorit?.adapter = listTanahAdapter

        listTanahAdapter.setOnItemClickCallback(object : NewAdapter.OnItemClickCallback {
            override fun onItemClicked(data: TanahModel) {
//                showDetailedStory(data)
            }
        })
    }

//    private fun showDetailedStory(data: TanahModel) {
//        val toDetailTanahFragment = HomeFragmentDirections.actionNavigationHomeToDetailTanahFragment()
//        toDetailTanahFragment.photo = data.photo
//        toDetailTanahFragment.tanah = data.name
//        toDetailTanahFragment.description = data.description
//        toDetailTanahFragment.lon = data.lon.toString()
//        toDetailTanahFragment.lat = data.lat.toString()
//        toDetailTanahFragment.id = data.id
//        findNavController().navigate(toDetailTanahFragment)
//    }

    private fun isLoading(isLoading: Boolean) {
        binding?.progressBar?.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}