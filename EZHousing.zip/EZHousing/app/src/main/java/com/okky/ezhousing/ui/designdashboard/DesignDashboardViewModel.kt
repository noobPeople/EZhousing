package com.okky.ezhousing.ui.designdashboard

import androidx.lifecycle.ViewModel

class DesignDashboardViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}