package com.okky.ezhousing.ui.dashboard.editprofile

import androidx.lifecycle.ViewModel

class EditProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}